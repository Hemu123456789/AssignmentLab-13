.list-social {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;
  }
  
  @media only screen and (max-width: 749px) {
    .list-social {
      justify-content: center;
    }
  }
  
  .list-social__item .icon {
    height: 1.8rem;
    width: 1.8rem;
  }
  
  .list-social__link {
    align-items: center;
    display: flex;
    padding: 1.3rem;
    color: rgb(var(--color-foreground));
  }
  
  .list-social__link:hover .icon {
    transform: scale(1.07);
  }
  