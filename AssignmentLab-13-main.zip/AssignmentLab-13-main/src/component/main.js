{
    "sections": {
      "main": {
        "type": "main-activate-account",
        "settings": {
          "padding_top": 36,
          "padding_bottom": 36
        }
      }
    },
    "order": [
      "main"
    ]
  }